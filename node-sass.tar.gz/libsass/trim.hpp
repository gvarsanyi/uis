// #define SASS_TRIM
// #include <vector>

// namespace Sass {
//   using std::vector;
//   class Complex_Selector;
//   vector<vector<Complex_Selector*> > trim(vector<vector<Complex_Selector*> >);
// }